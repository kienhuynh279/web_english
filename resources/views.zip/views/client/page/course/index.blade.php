<section class="my-section">
  <div class="container">
    <div class="col-sm-12">
      <div class="row">
        <a href="#">
          <p style="color:black">Trang chủ \ Ôn Thi THPT \ Theo dạng đề</p>
        </a>
      </div>
    </div>
  </div>
</section>
<section class="my-section-center">
  <div class="container">
    <div class="row">
      <div class="col-md-4 mb-5">
        <div class="simple-card">
          <a href="#">
            <div class="simple-card-image">
              <img src="{{ asset('dist/img/courses/c1.jpg') }}" alt="" />
            </div>
            <div class="simple-card-content">
              <h3 class="simple-card-title">Applying for a Design Job</h3>
          </a>
          <p>Số câu: 40 câu</p>
          <p>Thời gian: 60 phút</p>
          <a class="" href="">
            <button type="submit" class="download-form-submit">Làm bài</button>
          </a>
        </div>
      </div>
    </div>
    <div class="col-md-4 mb-5">
      <div class="simple-card">
        <a href="#">
          <div class="simple-card-image">
            <img src="{{ asset('dist/img/courses/c1.jpg') }}" alt="" />
          </div>
          <div class="simple-card-content">
            <h3 class="simple-card-title">Applying for a Design Job</h3>
        </a>
        <p>Số câu: 40 câu</p>
        <p>Thời gian: 60 phút</p>
        <a class="" href="">
          <button type="submit" class="download-form-submit">Làm bài</button>
        </a>
      </div>
    </div>
  </div>
  <div class="col-md-4 mb-5">
    <div class="simple-card">
      <a href="#">
        <div class="simple-card-image">
          <img src="{{ asset('dist/img/courses/c1.jpg') }}" alt="" />
        </div>
        <div class="simple-card-content">
          <h3 class="simple-card-title">Applying for a Design Job</h3>
      </a>
      <p>Số câu: 40 câu</p>
      <p>Thời gian: 60 phút</p>
      <a class="" href="">
        <button type="submit" class="download-form-submit">Làm bài</button>
      </a>
    </div>
  </div>
  </div>
  <div class="col-md-4 mb-5">
    <div class="simple-card">
      <a href="#">
        <div class="simple-card-image">
          <img src="{{ asset('dist/img/courses/c1.jpg') }}" alt="" />
        </div>
        <div class="simple-card-content">
          <h3 class="simple-card-title">Applying for a Design Job</h3>
      </a>
      <p>Số câu: 40 câu</p>
      <p>Thời gian: 60 phút</p>
      <a class="" href="">
        <button type="submit" class="download-form-submit">Làm bài</button>
      </a>
    </div>
  </div>
  </div>
  <div class="col-md-4 mb-5">
    <div class="simple-card">
      <a href="#">
        <div class="simple-card-image">
          <img src="{{ asset('dist/img/courses/c1.jpg') }}" alt="" />
        </div>
        <div class="simple-card-content">
          <h3 class="simple-card-title">Applying for a Design Job</h3>
      </a>
      <p>Số câu: 40 câu</p>
      <p>Thời gian: 60 phút</p>
      <a class="" href="">
        <button type="submit" class="download-form-submit">Làm bài</button>
      </a>
    </div>
  </div>
  </div>
  <div class="col-md-4 mb-5">
    <div class="simple-card">
      <a href="#">
        <div class="simple-card-image">
          <img src="{{ asset('dist/img/courses/c1.jpg') }}" alt="" />
        </div>
        <div class="simple-card-content">
          <h3 class="simple-card-title">Applying for a Design Job</h3>
      </a>
      <p>Số câu: 40 câu</p>
      <p>Thời gian: 60 phút</p>
      <a class="" href="">
        <button type="submit" class="download-form-submit">Làm bài</button>
      </a>
    </div>
  </div>
  </div>
  <div class="col-md-4 mb-5">
    <div class="simple-card">
      <a href="#">
        <div class="simple-card-image">
          <img src="{{ asset('dist/img/courses/c1.jpg') }}" alt="" />
        </div>
        <div class="simple-card-content">
          <h3 class="simple-card-title">Applying for a Design Job</h3>
      </a>
      <p>Số câu: 40 câu</p>
      <p>Thời gian: 60 phút</p>
      <a class="" href="">
        <button type="submit" class="download-form-submit">Làm bài</button>
      </a>
    </div>
  </div>
  </div>
  <div class="col-md-4 mb-5">
    <div class="simple-card">
      <a href="#">
        <div class="simple-card-image">
          <img src="{{ asset('dist/img/courses/c1.jpg') }}" alt="" />
        </div>
        <div class="simple-card-content">
          <h3 class="simple-card-title">Applying for a Design Job</h3>
      </a>
      <p>Số câu: 40 câu</p>
      <p>Thời gian: 60 phút</p>
      <a class="" href="">
        <button type="submit" class="download-form-submit">Làm bài</button>
      </a>
    </div>
  </div>
  </div>
  <div class="col-md-4 mb-5">
    <div class="simple-card">
      <a href="#">
        <div class="simple-card-image">
          <img src="{{ asset('dist/img/courses/c1.jpg') }}" alt="" />
        </div>
        <div class="simple-card-content">
          <h3 class="simple-card-title">Applying for a Design Job</h3>
      </a>
      <p>Số câu: 40 câu</p>
      <p>Thời gian: 60 phút</p>
      <a class="" href="">
        <button type="submit" class="download-form-submit">Làm bài</button>
      </a>
    </div>
    </a>
  </div>
  </div>

  <div class="text-center">
    <nav aria-label="Page navigation example">
      <ul class="pagination">
        <li class="page-item"><a class="page-link" href="#">Trước</a></li>
        <li class="page-item"><a class="page-link" href="#">1</a></li>
        <li class="page-item"><a class="page-link" href="#">2</a></li>
        <li class="page-item"><a class="page-link" href="#">3</a></li>
        <li class="page-item"><a class="page-link" href="#">Sau</a></li>
      </ul>
    </nav>
  </div>

</section>