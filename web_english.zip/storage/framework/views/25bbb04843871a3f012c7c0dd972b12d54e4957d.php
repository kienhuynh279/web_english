    <script src=<?php echo e(asset('dist/js/jquery-3.2.1.min.js')); ?>></script>
    <script src=<?php echo e(asset('dist/js/popper.js')); ?>></script>
    <script src=<?php echo e(asset('dist/js/bootstrap.min.js')); ?>></script>
    <script src=<?php echo e(asset('dist/vendors/nice-select/js/jquery.nice-select.min.js')); ?>></script>
    <script src=<?php echo e(asset('dist/vendors/owl-carousel/owl.carousel.min.js')); ?>></script>
    <script src=<?php echo e(asset('dist/js/owl-carousel-thumb.min.js')); ?>></script>
    <script src=<?php echo e(asset('dist/js/jquery.ajaxchimp.min.js')); ?>></script>
    <script src=<?php echo e(asset('dist/js/mail-script.js')); ?>></script>
     <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCjCGmQ0Uq4exrzdcL6rvxywDDOvfAu6eE"></script>
    <script src=<?php echo e(asset('dist/js/gmaps.min.js')); ?>></script>
    <script src=<?php echo e(asset('dist/js/theme.js')); ?>></script><?php /**PATH C:\xampp\htdocs\web_english\resources\views/client/components/js-import.blade.php ENDPATH**/ ?>