
<?php $__env->startSection('title','Trang Chủ Admin'); ?>
<?php $__env->startSection('main'); ?>

<div class="card">
    <div class="card-header">
         <a href="<?php echo e(asset('admin/user/add')); ?>" class="btn btn-primary"><i class="fas fa-plus-square"></i> Thêm Người Dùng</a>
    </div>
    <div class="card-body">
         <table id="dataTable" class="table table-striped table-bordered" style="width:100%">
              <thead>
                   <tr>
                        <th>ID User :</th>
                        <th>Tên Người Dùng : </th>
                        <th>Email Người Dùng : </th>
                        <th>Ảnh : </th>
                        <th>Tùy Chỉnh</th>
                   </tr>
              </thead>
              <tbody>
                   <?php $__currentLoopData = $userlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <tr>
                        <td><?php echo e($user->id); ?></td>
                        <td><?php echo e($user->username); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td>
                              <img width="200px" src="<?php echo e(asset('/app/upload/img/user/'.$user->avatar)); ?>" class="thumbnail">
                        </td>
                        <td>
                             <a href="<?php echo e(asset('admin/user/edit/'.$user->id)); ?>" class="btn btn-warning"><i class="fas fa-pencil-alt" aria-hidden="true"></i> Sửa</a>
                             <a onclick="return confirm('Bạn có chắc chắn muốn xóa !')" href="<?php echo e(asset('admin/user/delete/'.$user->id)); ?>" class="btn btn-danger"><i class="fa fa-trash" aria-hidden="true"></i> Xóa</a>
                        </td>
                   </tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
              <tfoot>
                   <tr>
                    <th>ID User :</th>
                    <th>Tên Người Dùng : </th>
                    <th>Email Người Dùng : </th>
                    <th>Ảnh : </th>
                    <th>Tùy Chỉnh</th>
                   </tr>
              </tfoot>
         </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<script>
    $("#dataTable").DataTable({
         "responsive": true,
         "autoWidth": true,
         "columns": [
              null,
              null,
              null,
              { "width": "20%" }
              ]
    });
</script>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\web_english\resources\views/admin/page/user/user.blade.php ENDPATH**/ ?>