<?php echo $__env->make('client.components.head-import', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('client.components.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div id="app">
     <?php switch($page ?? 'home'):
     case ('home.index'): ?>
     <?php echo $__env->make('client.page.home.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <?php break; ?>
     <?php case ('course.index'): ?>
     <?php echo $__env->make('client.page.course.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <?php break; ?>
     <?php case ('course.detail'): ?>
     <?php echo $__env->make('client.page.course.detail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <?php break; ?>
     <?php case ('course.list'): ?>
     <?php echo $__env->make('client.page.course.list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <?php break; ?>
     <?php case ('contact.index'): ?>
     <?php echo $__env->make('client.page.contact.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <?php break; ?>
     <?php case ('news.index'): ?>
     <?php echo $__env->make('client.page.news.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <?php break; ?>
     <?php case ('news.detail'): ?>
     <?php echo $__env->make('client.page.news.detail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <?php break; ?>
     <?php case ('login.index'): ?>
     <?php echo $__env->make('client.page.login.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <?php break; ?>
     <?php default: ?>
     <?php echo $__env->make('client.page.home.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <?php endswitch; ?>
</div>

<?php echo $__env->make('client.components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\web_english\resources\views/client/main.blade.php ENDPATH**/ ?>