<!DOCTYPE html>
<html lang="vi">

<head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <link rel="canonical" href="http://bdsnew.eso.vn/">
     <link rel="shortcut icon" href="<?php echo e(asset('dist/img/favicon.png')); ?>" type="image/x-icon">
     <title>Web English - <?php echo $__env->yieldContent('title'); ?></title>
     <?php echo $__env->yieldContent('head-import'); ?>
</head>

<body class="sidebar-mini layout-fixed pace-success">
     <?php echo $__env->yieldContent('main'); ?>
     <?php echo $__env->yieldContent('js-import'); ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\WebEnglish\resources\views/index-master.blade.php ENDPATH**/ ?>