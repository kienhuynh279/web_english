<div class="popular_courses section_gap_top">
  <div class="container">
  <div class="col-sm-12">
        <div class="row">
            <a href="#"><p style="color:black">Home\ Docs\Outstanding Docs </p></a>
        </div>
    </div>
  <div class="row">
    <div class="col-sm-3">
      <div class="category">
        <div class="category-title">
            <h3 class="mb-3">Categorys</h3>
        </div>
        <div class="item-category">
          <h6 class="item">Toeic Docs (60 docs)<h6>
          <h6 class="item">Toeic Docs (60 docs)<h6>
          <h6 class="item">Toeic Docs (60 docs)<h6>
          <h6 class="item">Toeic Docs (60 docs)<h6>
          <h6 class="item">Toeic Docs (60 docs)<h6>
        </div>
      </div>
    </div>
    
    <div class="col-sm-9">
      <div class="row justify-content-center">
        <div class="col-lg-5">
          <div class="main_title">
            <h2 class="mb-3">Outstanding Docs</h2>
          </div>
        </div>
      </div>
 <div class="row">
        <div class="col-sm-12">
          <div class="projcard-container">
            <div class="projcard projcard-customcolor" style="--projcard-color: #ea695f;">
              <div class="projcard-innerbox">
                <img class="projcard-img" src="<?php echo e(asset('dist/img/courses/c1.jpg')); ?>" />
                <div class="projcard-textbox">
                    <div class="projcard-title"><span></span></div>
                    <div class="projcard-subtitle">That's the last one. Have a nice day!</div>
                    <div class="projcard-bar"></div>
                    <div class="projcard-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</div>
                    <div class="label">
                      <a href="<?php echo e(route('courseDetail')); ?>"><span class="label-item danger">Detail</span></a>
                    <a href=""><span class="label-item success">Download</span></a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

 <div class="row">
        <div class="col-sm-12">
          <div class="projcard-container">
            <div class="projcard projcard-customcolor" style="--projcard-color: #ea695f;">
              <div class="projcard-innerbox">
                <img class="projcard-img" src="<?php echo e(asset('dist/img/courses/c1.jpg')); ?>" />
                <div class="projcard-textbox">
                  <div class="projcard-title"><span></span></div>
                  <div class="projcard-subtitle">That's the last one. Have a nice day!</div>
                  <div class="projcard-bar"></div>
                  <div class="projcard-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</div>
                  <div class="label">
                    <a href="<?php echo e(route('courseDetail')); ?>"><span class="label-item danger">Detail</span></a>
                    <a href=""><span class="label-item success">Download</span></a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-sm-12">
          <div class="projcard-container">
            <div class="projcard projcard-customcolor" style="--projcard-color: #ea695f;">
              <div class="projcard-innerbox">
                <img class="projcard-img" src="<?php echo e(asset('dist/img/courses/c1.jpg')); ?>" />
                <div class="projcard-textbox">
                  <div class="projcard-title"><span></span></div>
                  <div class="projcard-subtitle">That's the last one. Have a nice day!</div>
                  <div class="projcard-bar"></div>
                  <div class="projcard-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</div>
                  <div class="label">
                    <a href="<?php echo e(route('courseDetail')); ?>"><span class="label-item danger">Detail</span></a>
                    <a href=""><span class="label-item success">Download</span></a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-sm-12">
          <ul class="pagi">
              <li class="pagi-item pagi-action pagi-prev is-disabled">
                <i class="ti-angle-left"></i>
              </li>
              <li class="pagi-item is-active">1</li>
              <li class="pagi-item">2</li>
              <li class="pagi-item">3</li>
              <li class="pagi-item">4</li>
              <li class="pagi-item">5</li>
              <li class="pagi-item pagi-action pagi-next">
              <i class="ti-angle-right"></i>
              </li>
            </ul>
        </div>
      </div>

    </div>
  </div>
  </div>
</div>  
<?php /**PATH C:\xampp\htdocs\WebEnglish\resources\views/client/page/course/index.blade.php ENDPATH**/ ?>