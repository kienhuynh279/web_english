    <footer class="footer-area section_gap">
      <div class="container">
        <div class="row">
          <div class="col-lg-3 col-md-6 single-footer-widget">
            <h4>Abouts Us</h4>
            <ul>
              <li><a style="color:  #002347" href="#">User Manual</a></li>
              <li><a style="color:  #002347" href="#">Privacy Policy</a></li>
              <li><a style="color:  #002347" href="#">Terms of Use</a></li>
            </ul>
          </div>
          <div class="col-lg-3 col-md-6 single-footer-widget">
            <h4>Pass-level review</h4>
            <ul>
              <li><a style="color:  #002347" href="#">Put it to class 10</a></li>
              <li><a style="color:  #002347" href="#">High school graduation exam</a></li>
              <li><a style="color:  #002347" href="#">College entrance exam</a></li>
            </ul>
          </div>
          <div class="col-lg-3 col-md-6 single-footer-widget">
            <h4>Certificate of certificate</h4>
            <ul>
              <li><a style="color:  #002347" href="#">Toeic</a></li>
              <li><a style="color:  #002347" href="#">Toefl</a></li>
              <li><a style="color:  #002347" href="#">Ielts</a></li>
            </ul>
          </div>
          <div class="col-lg-3 col-md-6 single-footer-widget">
            <h4>Contact</h4>
            <ul>
              <li><a style="color:  #002347" href="#"><i class="ti-location-pin"></i> xx, TP HCM</a><li>
              <li><a style="color:  #002347" href="#"><i class="ti-mobile"></i> +xxx xxxx xxx</a></li>
              <li><a style="color:  #002347" href="#"><i class="ti-google"></i> gmail@gmail.com</i></a></li>
              <li><a style="color:  #002347" href="#"><i class="ti-facebook"></i> Account FB</i></a></li>
            </ul>
          </div>
        </div>
      </div>
</footer><?php /**PATH C:\xampp\htdocs\web_english\resources\views/client/components/footer.blade.php ENDPATH**/ ?>