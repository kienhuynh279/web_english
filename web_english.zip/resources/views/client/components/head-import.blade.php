    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />
    <link rel="icon" href={{ asset('dist/img/favicon.png') }} type="image/png" />
    
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href={{ asset('dist/css/bootstrap.css') }} />
    <link rel="stylesheet" href={{ asset('dist/css/flaticon.css') }} />
    <link rel="stylesheet" href={{ asset('dist/css/themify-icons.css') }} />
    <link rel="stylesheet" href={{ asset('dist/vendors/owl-carousel/owl.carousel.min.css') }} />
    <link rel="stylesheet" href={{ asset('dist/vendors/nice-select/css/nice-select.css') }} />
    <!-- main css -->
    <link rel="stylesheet" href={{ asset('dist/css/style.css') }} />
    {{-- <script data-ad-client="ca-pub-1234567890123456" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script> --}}